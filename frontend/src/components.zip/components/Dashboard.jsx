import { useEffect, useState } from "react";
import axios from "axios";
import "./Dashboard.css";
import ShimmerD from "./ShimmerD";
import { useNavigate } from "react-router-dom";

const BASE = import.meta.env.VITE_API_BASE_URL;

const Dashboard = () => {
  const [data, setData] = useState(null);
  const navigate = useNavigate();

  const handleLogout = async () => {
    await axios.post(`${BASE}/sheet/logout.php`, {}, { withCredentials: true });
    // localStorage.removeItem("token");
    navigate("/");
  };

  useEffect(() => {
    axios
      .get(`${BASE}/sheet/dashboard.php`, { withCredentials: true })
      .then((res) => setData(res.data))
      .catch((err) => console.error(err));
  }, []);

  if (!data) return <ShimmerD />;

  // const { metrics } = data;
  const { metrics, centre, user } = data;

  return (
    <div className="dashboard">
      <div className="header" style={{ position: "relative" }}>
        {/* <h1>Curasia Hospital - Zirakpur</h1>
        <h2>Dialysis Centre Dashboard</h2> */}

        <h1>{centre}</h1>
        <h2>{user} - Dialysis Centre Dashboard</h2>
        <button
          onClick={handleLogout}
          style={{
            position: "absolute",
            right: "20px",
            top: "20px",
            padding: "8px 16px",
            borderRadius: "8px",
            border: "none",
            background: "#ef4444",
            color: "#fff",
            cursor: "pointer",
            fontWeight: 500,
            fontSize: "14px",
          }}
        >
          Logout
        </button>
      </div>

      <div className="nav">
        <span className="active">Quick View</span>
      </div>

      <div className="main">
        <div className="sessions-box">
          <h2>Sessions</h2>
          <div className="box-row">
            <div className="border-box green">
              <h4>MTD Sessions</h4>
              <h1>{metrics?.mtdSessions}</h1>
              <p>Since last month</p>
            </div>
            <div className="border-box blue">
              <h4>Last Month Sessions</h4>
              <h1>{metrics?.lastMonthSessions}</h1>
            </div>
            <div className="border-box orange">
              <h4>Patients</h4>
              <h1>{metrics?.patients}</h1>
            </div>
            <div className="border-box machine-box">
              <h4>Dialysis Machines Active</h4>
              <h1>{metrics?.activeMachines}</h1>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
